/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Entities.Emplois;
import Utils.Maconnexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author 21624
 */
public class ServiceEmplois  {
      Connection cnx;
    private List<Emplois> emplois;
    private PreparedStatement pre;
    private Statement ste;
    public ServiceEmplois() {
cnx =Maconnexion.getInstance().getConnection();
        }  
    
   public void AddEmploi(Emplois e) throws SQLException  {
  
        String req ="INSERT INTO emploi (id,offre_id,salaire,type_contrat) VALUES (?,?,?,?)";
        
        try {
            PreparedStatement stm = cnx.prepareStatement(req);
           stm.setInt(1, e.getIdemploi());
             stm.setInt(2, e.getOffre_id());
             stm.setInt(3,e.getSalaire());
             stm.setString(4, e.getType_contrat());
                          
             stm.executeUpdate();
             System.out.println("emploi ajouté");
                     
        } catch (SQLException ex) {
            System.out.println("probleme");
            System.out.println(ex.getMessage());
        }       
    }
    public List<Emplois> afficherEmplois() throws SQLException {
     List<Emplois> resulta = new ArrayList<>();

     Statement stm=cnx.createStatement();
     String query="select * from emploi ";
     
ResultSet resultat = stm.executeQuery(query) ;   
               Emplois e=new Emplois();
       while(resultat.next()) {
           e.setIdemploi(resultat.getInt("id"));
             e.setOffre_id(resultat.getInt("offre_id"));
                 e.setSalaire(resultat.getInt("salaire"));              
               e.setType_contrat(resultat.getString("type_contrat"));
                                     
               resulta.add(e);
       } 

       return resulta;   
 }
     public void supprimerEmploi(Emplois e){
       String req="delete from emploi where id=?";
       
        try {
            
            PreparedStatement stm;
            stm=cnx.prepareStatement(req);
            stm.setInt(1,e.getIdemploi() );
            int i=stm.executeUpdate();
            System.out.println(i+ " emploi suprimé");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
   }
      public int ModifierEmploi(int id,Emplois e) throws SQLException {
        if(chercher(id)){
        
        pre=cnx.prepareStatement("UPDATE emploi SET offre_id=?, salaire = ? , type_contrat = ?   WHERE id = "+id+"");
    try{     
    pre.setInt(1, e.getOffre_id());
     pre.setInt(2, e.getSalaire());
    pre.setString(3, e.getType_contrat());
    
    
    pre.executeUpdate();
    }
    catch (SQLException m){
      System.out.println(m.getMessage());  
    }
    return 1;}
        return 0;
    }
      public boolean chercher(int id) throws SQLException {
        String req="select * from emploi";
        List<Integer> list = new ArrayList<>();
        
        try {
            ste=cnx.createStatement();
            ResultSet rs = ste.executeQuery(req);
            while(rs.next()){
                list.add(rs.getInt(1));
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServiceEmplois.class.getName()).log(Level.SEVERE, null, ex);
        }
        list.forEach(System.out::println);
        return list.contains(id);
    }
}

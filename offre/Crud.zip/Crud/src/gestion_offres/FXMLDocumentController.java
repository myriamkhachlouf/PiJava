/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestion_offres;

import Entities.Offres;
import Service.ServiceOffres;
import Utils.Maconnexion;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author 21624
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    @FXML
    private TextField tfid_offre;
    @FXML
    private Button Btn_modifier;
    @FXML
    private TextField tfnom_offre;
    @FXML
    private ComboBox<String> idpromotion_offre;
    @FXML
    private TextField tfimage_offre;
    @FXML
    private ComboBox<String> idtype_offre;
    @FXML
    private Button Btn_suivant;
    @FXML
    private Button Btn_ajouter;
    @FXML
    private AnchorPane parent;
   
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    ObservableList<String> data = FXCollections.observableArrayList("1","2","3","4","5","6");
    ObservableList<String> data2 = FXCollections.observableArrayList("stage","emploi");
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        idpromotion_offre.setItems(data);
        idtype_offre.setItems(data2);
    }    

    @FXML
    private void ajouter_offre(ActionEvent event) throws SQLException {
         ServiceOffres aa = new ServiceOffres();
        Scanner sc = new Scanner(System.in);
        Connection cnx = Maconnexion.getInstance().getConnection();
        Statement st;
        ResultSet rs;
        st = cnx.createStatement();
        Statement stm = cnx.createStatement();
        String SQL = "SELECT * FROM offre   WHERE id ='" + tfid_offre.getText() + "' ";
        rs = stm.executeQuery(SQL);
        if (!rs.next()) {
            if ((!tfnom_offre.getText().matches("[\\\\!\"#$%&()*+,./:;<=>?@\\[\\]^_{|}~]+"))
                    && (!tfimage_offre.getText().matches("[\\\\!\"#$%&()*+,./:;<=>?@\\[\\]^_{|}~]+"))) {
                String req = "insert into offre (id,entreprise_id,nom_offre,image_name,type)values('" + tfid_offre.getText() + "','" + idpromotion_offre.getValue() + "','" + tfnom_offre.getText() + "' ,'" + tfimage_offre.getText() + "','" + idtype_offre.getValue() + "','')";
               
               try {
                    st = cnx.createStatement();
                    st.executeQuery(req);
                    
                } catch (SQLException ex) {
                    Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                
                

            } 

            Offres a = new Offres();
            a.setId(Integer.parseInt(tfid_offre.getText()));
            a.setEntreprise_id(Integer.parseInt(idpromotion_offre.getValue()));
            a.setNom_offre(tfnom_offre.getText());
            a.setImage_name(tfimage_offre.getText());
            a.setType(idtype_offre.getValue());
            try {
                    
                aa.AddOffre(a);             
                tfid_offre.clear();
                  tfnom_offre.clear();
                    tfimage_offre.clear();                  
                
            } catch (SQLException ex) {

            }
        }
    }

    @FXML
    private void modifier_offre(ActionEvent event) throws SQLException {
        ServiceOffres sr = new ServiceOffres();
        Offres a = new Offres();
        int id;
        id = Integer.parseInt(tfid_offre.getText());
        a.setId(Integer.parseInt(tfid_offre.getText()));
            a.setEntreprise_id(Integer.parseInt(idpromotion_offre.getValue()));
            a.setNom_offre(tfnom_offre.getText());
            a.setImage_name(tfimage_offre.getText());
            a.setType(idtype_offre.getValue());

        sr.ModifierOffre(id, a);
        
        tfid_offre.clear();
                  tfnom_offre.clear();
                    tfimage_offre.clear();     
    }

    @FXML
    private void Suivant(ActionEvent event) throws IOException {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("/gestion_offres/metiers.fxml"));
         parent.getChildren().setAll(pane);
    }

    
}

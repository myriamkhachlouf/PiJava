/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestion_offres;


import Entities.Emplois;
import Service.ServiceEmplois;
import Service.ServiceOffres;
import Utils.Maconnexion;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author 21624
 */
public class EmploiController implements Initializable {

    @FXML
    private AnchorPane filss;
    @FXML
    private Label label;
    @FXML
    private TextField tfid_emploi;
    @FXML
    private Button Btn_modifier;
    @FXML
    private TextField tfsalaire_emploi;
    @FXML
    private ComboBox<String> idoffre_emploi;
    @FXML
    private ComboBox<String> idtype_emploi;
    @FXML
    private Button Btn_suivant;
    @FXML
    private Button Btn_ajouter;

    /**
     * Initializes the controller class.
     */
     ObservableList<String> data = FXCollections.observableArrayList("1","2","3","4","5","6");
    ObservableList<String> data2 = FXCollections.observableArrayList("normal","extra");
    @FXML
    private Button Btn_precedent1;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         idoffre_emploi.setItems(data);
        idtype_emploi.setItems(data2);
    }    

    @FXML
    private void Suivant(ActionEvent event) throws IOException {
                    AnchorPane pane = FXMLLoader.load(getClass().getResource("/gestion_offres/metiersEmploi.fxml"));
                     filss.getChildren().setAll(pane);
    }

    @FXML
    private void ajouter_emploi(ActionEvent event) throws SQLException {
        ServiceEmplois aa = new ServiceEmplois();
        Scanner sc = new Scanner(System.in);
        Connection cnx = Maconnexion.getInstance().getConnection();
        Statement st;
        ResultSet rs;
        st = cnx.createStatement();
        Statement stm = cnx.createStatement();
        String SQL = "SELECT * FROM emploi   WHERE id ='" + tfid_emploi.getText() + "' ";
        rs = stm.executeQuery(SQL);
        if (!rs.next()) {
            if ((!tfid_emploi.getText().matches("[\\\\!\"#$%&()*+,./:;<=>?@\\[\\]^_{|}~]+"))
                    && (!tfsalaire_emploi.getText().matches("[\\\\!\"#$%&()*+,./:;<=>?@\\[\\]^_{|}~]+"))) {
                String req = "insert into emploi (id,offre_id,salaire,type_contrat)values('" + idoffre_emploi.getValue() + "','" + tfsalaire_emploi.getText() + "' ,'" + idtype_emploi.getValue() + "','')";
               
               try {
                    st = cnx.createStatement();
                    st.executeQuery(req);
                    
                } catch (SQLException ex) {
                    Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                
                

            } 

            Emplois a = new Emplois();
            a.setIdemploi(Integer.parseInt(tfid_emploi.getText()));
            a.setOffre_id(Integer.parseInt(idoffre_emploi.getValue()));
            a.setSalaire(Integer.parseInt(tfsalaire_emploi.getText()));
           
            a.setType_contrat(idtype_emploi.getValue());
            try {
                    
                aa.AddEmploi(a);             
                tfid_emploi.clear();
                  tfsalaire_emploi.clear();
                           
                
            } catch (SQLException ex) {

            }
        }
    }

    @FXML
    private void modifier_emploi(ActionEvent event) throws SQLException {
        ServiceEmplois sr = new ServiceEmplois();
        Emplois e = new Emplois();
        int id;
        id = Integer.parseInt(tfid_emploi.getText());
        e.setIdemploi(Integer.parseInt(tfid_emploi.getText()));
            e.setOffre_id(Integer.parseInt(idoffre_emploi.getValue()));
            e.setSalaire(Integer.parseInt(tfsalaire_emploi.getText()));
            e.setType_contrat(idtype_emploi.getValue());

        sr.ModifierEmploi(id, e);
        
           tfid_emploi.clear();
                  tfsalaire_emploi.clear();
                  
    }

    @FXML
    private void precedentt(ActionEvent event) throws IOException {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("/gestion_offres/metiers.fxml"));
         filss.getChildren().setAll(pane);
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestion_offres;

import Entities.Offres;
import Utils.Maconnexion;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author 21624
 */
public class MetiersController implements Initializable {
    @FXML
    private AnchorPane fils;
    @FXML
    private Button Btn_precedent;
    @FXML
        private TableView<Offres> table;
    @FXML
    private TableColumn<Offres, Integer> idoffre;
    @FXML
    private TableColumn<Offres, Integer> idpromooffre;
    @FXML
    private TableColumn<Offres, Integer> nomoffre;
    @FXML
    private TableColumn<Offres, Integer> imageoffre;
    @FXML
    private TableColumn<Offres, Integer> typeoffre;
    /**
     * Initializes the controller class.
     * 
     */
     ObservableList<Offres> offreList = FXCollections.observableArrayList();
    ObservableList<Offres> offreList2;
    @FXML
    private Button Btn_supprimer;
    @FXML
    private Button Stage;
    @FXML
    private Button Emploi;
        
     public void showaliment() {
        try {
            Connection cnx = Maconnexion.getInstance().getConnection();
            String query = "SELECT * FROM offre";
            Statement st;
            ResultSet rs;
            st = cnx.createStatement();
            rs = st.executeQuery(query);
            Offres offres;
            while (rs.next()) {
                offres = new Offres(rs.getInt("id"), rs.getInt("entreprise_id"), rs.getString("nom_offre"), rs.getString("image_name"), rs.getString("type"));
                offreList.add(offres);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Error on Building Data");
        }
        idoffre.setCellValueFactory(new PropertyValueFactory<>("id"));
        idpromooffre.setCellValueFactory(new PropertyValueFactory<>("entreprise_id"));
        nomoffre.setCellValueFactory(new PropertyValueFactory<>("nom_offre"));
        imageoffre.setCellValueFactory(new PropertyValueFactory<>("image_name"));
        typeoffre.setCellValueFactory(new PropertyValueFactory<>("type"));
        

        table.setItems(offreList);
    }
     public void showaliment2() {
       offreList.removeAll(offreList);
         try {
            Connection cnx = Maconnexion.getInstance().getConnection();
            String query = "SELECT * FROM offre";
            Statement st;
            ResultSet rs;
            st = cnx.createStatement();
            rs = st.executeQuery(query);
            Offres offres;
            while (rs.next()) {
                offres = new Offres(rs.getInt("id"), rs.getInt("entreprise_id"), rs.getString("nom_offre"), rs.getString("image_name"), rs.getString("type"));
                offreList.add(offres);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Error on Building Data");
        }
        idoffre.setCellValueFactory(new PropertyValueFactory<>("id"));
        idpromooffre.setCellValueFactory(new PropertyValueFactory<>("entreprise_id"));
        nomoffre.setCellValueFactory(new PropertyValueFactory<>("nom_offre"));
        imageoffre.setCellValueFactory(new PropertyValueFactory<>("image_name"));
        typeoffre.setCellValueFactory(new PropertyValueFactory<>("type"));
        

        table.setItems(offreList);
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        showaliment();
    }   
    @FXML
    private void precedent(ActionEvent event) throws IOException {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("/gestion_offres/FXMLDocument.fxml"));
         fils.getChildren().setAll(pane);
    }

    @FXML
    private void supprimer_offre(ActionEvent event) {
         offreList2=table.getSelectionModel().getSelectedItems();
         Connection cnx = Maconnexion.getInstance().getConnection();
            int id;
            id=offreList2.get(0).getId();
            System.out.println(id);
             
        try {
            
           String query = "delete from offre WHERE id = ?";
      PreparedStatement preparedStmt = cnx.prepareStatement(query);
      preparedStmt.setInt(1, id);

      // execute the preparedstatement
      preparedStmt.execute();
       
                 
      
     
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
         showaliment2();
    }

    @FXML
    private void suivantEmploi(ActionEvent event) throws IOException {
         AnchorPane pane = FXMLLoader.load(getClass().getResource("/gestion_offres/Emploi.fxml"));
         fils.getChildren().setAll(pane);
    }

  
  
    }
    

